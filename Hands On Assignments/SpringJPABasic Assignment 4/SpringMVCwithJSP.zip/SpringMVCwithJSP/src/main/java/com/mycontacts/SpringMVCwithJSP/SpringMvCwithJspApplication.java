package com.mycontacts.SpringMVCwithJSP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvCwithJspApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvCwithJspApplication.class, args);
	}

}
