package com.mycontacts.SpringMVCwithJSP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvCwithJspApplicationTests {

	@Test
	void contextLoads() {
	}

}
