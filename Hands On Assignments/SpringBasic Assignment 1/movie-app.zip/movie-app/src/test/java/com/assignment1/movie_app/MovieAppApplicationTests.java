package com.assignment1.movie_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
