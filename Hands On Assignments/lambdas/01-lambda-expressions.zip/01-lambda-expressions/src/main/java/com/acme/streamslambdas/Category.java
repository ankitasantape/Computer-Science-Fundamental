
package com.acme.streamslambdas;

public enum Category {
    FOOD,
    UTENSILS,
    CLEANING,
    OFFICE
}
